create function obj_description(oid, name) returns text
    stable
    strict
    parallel safe
    language sql
BEGIN ATOMIC
 SELECT pg_description.description
    FROM pg_description
   WHERE ((pg_description.objoid = $1) AND (pg_description.classoid = ( SELECT pg_class.oid
            FROM pg_class
           WHERE ((pg_class.relname = $2) AND (pg_class.relnamespace = ('pg_catalog'::regnamespace)::oid)))) AND (pg_description.objsubid = 0));
END;

comment on function obj_description(oid, name) is 'get description for object id and catalog name';

alter function obj_description(oid, name) owner to postgres;

